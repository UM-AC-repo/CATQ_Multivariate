# Hierarchy-preserving imputation strategy

## Decision

Do not independently fill a questionnaire total and its subscores. Impute the
lowest valid observed level first and derive every higher-level score
deterministically:

1. questionnaire items, when available;
2. subscores from the completed items;
3. total from the completed subscores/items;
4. screening cutoff from the completed total;
5. z-scores after all imputations and derivations.

This is passive imputation: derived variables are recalculated from their
current components rather than assigned a separate statistical imputation.

## Dataset-specific findings

The supplied file contains 195 participants and 19 missing cells across eight
participants.

- `CAT-Q = CAT-Q_comp + CAT-Q_mask + CAT-Q_assim` is valid in all 195 rows.
- `AQ10_max` equals the sum of its five components in all 191 rows where the
  total and all components are observed.
- The current `AQ10` total equals the sum of its five named subscores in only
  23 of 187 fully observed rows. There are 164 contradictory complete rows.
- Every missing `AQ10` total has `AQ10_cutoff = 1`. Filling those totals with
  the overall mean or median can therefore create scores below the established
  cutoff and is not coherent.

The five current AQ10 subscore columns are therefore quarantined from the
completed datasets. They should be reconstructed from the original ten item
responses or recovered from an earlier correctly keyed source. They must not be
used for subscore analyses in their current state.

## Implemented fallback

The accompanying script creates 20 completed datasets:

- Missing `AQ10_max` components are filled first using a nearby complete donor
  selected from participants with similar observed questionnaire and
  demographic profiles.
- `AQ10_max` is then recomputed exactly as the sum of its five components.
- Missing current `AQ10` totals are filled from nearby observed donors within
  the same `AQ10_cutoff` group. This preserves the known threshold while the
  corrupted current subscores remain quarantined.
- `CAT-Q` and its components are preserved because their hierarchy is already
  coherent.
- All observed values are preserved.
- Imputation flags, z-scores, a draw-level audit table, and automated
  identity checks are produced.

The first completed dataset may be used for exploratory inspection. For
inferential analyses, fit the same analysis separately in all 20 datasets and
pool estimates and standard errors using Rubin's rules.

## Preferred final solution

If the ten AQ-10 item responses can be recovered, they should replace the
total-level fallback:

1. score each item as 0/1 using the official key;
2. impute missing binary items using a binary chained-equations model;
3. recompute the five two-item domain scores;
4. sum the ten scored items to obtain `AQ10`;
5. calculate `AQ10_cutoff = 1` when `AQ10 >= 6`;
6. repeat this across multiple imputations and pool the eventual analysis.

The official AQ-10 scoring sheet states that each item contributes at most one
point, the total is the sum of the ten items, and a score of six or more is the
referral threshold.

## Sources

- Official University of Cambridge AQ-10 scoring sheet:
  https://www.autismresearchcentre.com/content/uploads/2024/11/AQ10.pdf
- Allison C, Auyeung B, Baron-Cohen S. Toward Brief “Red Flags” for Autism
  Screening (2012):
  https://docs.autismresearchcentre.com/papers/2012_Allisonetal_JAACAP_RedFlags.pdf
- Hull L et al. Development and Validation of the Camouflaging Autistic Traits
  Questionnaire:
  https://link.springer.com/article/10.1007/s10803-018-3792-6
- Van Buuren S. Flexible Imputation of Missing Data, derived variables and sum
  scores:
  https://stefvanbuuren.name/fimd/sec-knowledge.html
- Van Buuren S, Groothuis-Oudshoorn K. mice: Multivariate Imputation by Chained
  Equations:
  https://www.jstatsoft.org/article/view/v045i03
